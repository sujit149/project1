package com.morningstar.exception;

public class WrongOtpException extends Exception {
	
	public WrongOtpException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public  WrongOtpException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
