package com.morningstar.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Levels {
	
	@Id
	@Column
	private int levelId;
	
	@Column
	private String levelName;
	
	@OneToMany(mappedBy = "level")
	private List<Statuses> status;

	@OneToMany(mappedBy = "level")
	private List<Scores> score;

	@OneToMany(mappedBy = "level")
	private List<Questions> question;
	
	public List<Questions> getQuestion() {
		return question;
	}

	public void setQuestion(List<Questions> question) {
		this.question = question;
	}

	public List<Scores> getScore() {
		return score;
	}

	public void setScore(List<Scores> score) {
		this.score = score;
	}

	public List<Statuses> getStatus() {
		return status;
	}

	public void setStatus(List<Statuses> status) {
		this.status = status;
	}

	public int getLevelId() {
		return levelId;
	}

	public void setLevelId(int levelId) {
		this.levelId = levelId;
	}

	public String getLevelName() {
		return levelName;
	}

	public void setLevelName(String levelName) {
		this.levelName = levelName;
	}
	
}
