package com.morningstar.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Subjects {
	
	@Id
	@Column
	private int subjectId;
	
	@Column
	private String subjectName;
	
	@OneToMany(mappedBy = "subject")
	private List<Questions> question;
	
	@OneToMany(mappedBy = "subject")
	private List<Statuses> status;
	
	@OneToMany(mappedBy = "subject")
	private List<Scores> score;

	public List<Scores> getScore() {
		return score;
	}

	public void setScore(List<Scores> score) {
		this.score = score;
	}

	public List<Statuses> getStatus() {
		return status;
	}

	public void setStatus(List<Statuses> status) {
		this.status = status;
	}

	public List<Questions> getQuestion() {
		return question;
	}

	public void setQuestion(List<Questions> question) {
		this.question = question;
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}	

}
