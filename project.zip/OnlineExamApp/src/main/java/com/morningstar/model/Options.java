package com.morningstar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Options {
	
	@Id
	@Column
	private int optionId;
	
	@Column
	private String answerOptions;
	
	@Column
	private boolean answerStatus;
	
	@ManyToOne
	@JoinColumn(name = "questionId")
	private Questions question;

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public String getAnswerOptions() {
		return answerOptions;
	}

	public void setAnswerOptions(String answerOptions) {
		this.answerOptions = answerOptions;
	}

	public boolean isAnswerStatus() {
		return answerStatus;
	}

	public void setAnswerStatus(boolean answerStatus) {
		this.answerStatus = answerStatus;
	}

	public Questions getQuestion() {
		return question;
	}

	public void setQuestion(Questions question) {
		this.question = question;
	}

}
