package com.morningstar.model;

import java.time.LocalDate;
import java.time.Year;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Student {

	@Id
	@Column
	private int studentId;
	
	@Column
	private String studentName;
	
	@Column
	private String studentEmail;
	
	@Column
	private String studentPassword;
	
	@Column
	private String dateOfBirth;
	
	@Column
	private String city;
	
	@Column
	private String mobileNo;
	
	@Column
	private String state;
	
	@Column
	private String qualification;

	@Column
	private String yearofCompletion;
	
	@OneToMany(mappedBy = "student")
	private List<Statuses> status;
	
	@OneToMany(mappedBy = "student")
	private List<Scores> score; 
	
	public List<Scores> getScore() {
		return score;
	}

	public void setScore(List<Scores> score) {
		this.score = score;
	}

	public List<Statuses> getStatus() {
		return status;
	}

	public void setStatus(List<Statuses> status) {
		this.status = status;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getYearofCompletion() {
		return yearofCompletion;
	}

	public void setYearofCompletion(String yearofCompletion) {
		this.yearofCompletion = yearofCompletion;
	}
	
}
