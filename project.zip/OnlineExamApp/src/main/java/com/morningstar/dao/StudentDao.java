package com.morningstar.dao;

import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.morningstar.model.Student;

public interface StudentDao {
	
	public boolean isNewUser(String email);
	public boolean userRegistration(Student student);
	public boolean existUser(String email);
	public boolean updatePassword(String email,String password);
}
