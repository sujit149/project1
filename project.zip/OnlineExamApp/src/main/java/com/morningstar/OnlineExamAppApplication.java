package com.morningstar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineExamAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineExamAppApplication.class, args);
	}

}
