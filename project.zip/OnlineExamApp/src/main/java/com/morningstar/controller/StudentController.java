package com.morningstar.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.morningstar.exception.CustomerOtpException;
//import com.AirLinesApp.demoAirLines.dto.OtpStatus;
import com.morningstar.exception.UseralreadyRegistered;
import com.morningstar.exception.WrongOtpException;
import com.morningstar.model.Student;
import com.morningstar.service.StudentService;
import com.morningstar.dto.OtpStatus;

@Controller
public class StudentController {
	
	
	@Autowired
	StudentService service;
	
	@GetMapping(path = "/")
	public String hello() {
		return "index";
		}
	
	@GetMapping(path = "/Registration.view")
	public String registerPage() {
		return "Registration";
		}
	
	@PostMapping(path = "/registration.do")
	public String registration(Student student, Model model) {
		try {
			String message = service.checkUser(student);
			model.addAttribute("messageObj", message);
			return "Thankyou";
		}
		catch(UseralreadyRegistered e) {
			String message = e.getMessage();
			model.addAttribute("messageObj", message);
			return "Error";
		}
		
	}
	
	@GetMapping(path = "/Forgot.view")
	public String forgotPage() {
		return "Forgot";
		}
	

	@PostMapping("/sendOtp")
	public String userOtp(Student student, Model model) {
		try {
			String checkedEmail = service.isValidUser(student);
			String message = "Email sent successfully to : "+checkedEmail;
			model.addAttribute("messageObj", message);
			return "varify_otp";
		}
		catch(CustomerOtpException coe) {
			String message = coe.getMessage();
			model.addAttribute("messageObj", message);
			return "Error";
		}
	}
	
	@PostMapping("/getOtp")
	public String checkOtp(String otp, Model model) {
		try {
			String message = service.isValidOtp(otp);
			model.addAttribute("messageObj", message);
			return "UpdatePassword";
		}
		catch(WrongOtpException woe) {
			String message = woe.getMessage();
			model.addAttribute("messageObj", message);
			return "Error";
		}
	}
	
	
	@PostMapping("/changePassword")
	public String changePassword(Student student, Model model) {
	
		String message = service.updatePassword(student);
		//String message = "Email sent successfully to : "+checkedEmail;
		model.addAttribute("messageObj", message);
		return "Thankyou";
	
	
	
	}
	
	
}