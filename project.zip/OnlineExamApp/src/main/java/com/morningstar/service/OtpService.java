package com.morningstar.service;

import java.util.Random;

import org.springframework.stereotype.Service;

import com.morningstar.exception.WrongOtpException;
@Service
public class OtpService {
	

	static String otp;
	
	
	
	public String createOtp() {
		
		otp = "";
		Random rnd = new Random();
		String selectFrom="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
		while(otp.length()<7) {
            char ch = selectFrom.charAt(rnd.nextInt(selectFrom.length()));
            otp=otp+ch;
		}
		return otp;
	}
	
	public String checkOtp(String userOtp) throws WrongOtpException {
		if(otp.equals(userOtp)) {
			return "Otp verified successfully Please update the password.";
		}
		throw new WrongOtpException("Please enter correct Otp");
	}
}



