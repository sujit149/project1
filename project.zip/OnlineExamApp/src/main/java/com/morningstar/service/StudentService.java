package com.morningstar.service;

import org.springframework.stereotype.Service;

import com.morningstar.exception.CustomerOtpException;
import com.morningstar.exception.WrongOtpException;
import com.morningstar.model.Student;

public interface StudentService {
	
	public String checkUser(Student student);
	
	public String isValidUser(Student student) throws CustomerOtpException;
	
	 public String isValidOtp(String otp) throws WrongOtpException;

	 public String updatePassword(Student student);
}
