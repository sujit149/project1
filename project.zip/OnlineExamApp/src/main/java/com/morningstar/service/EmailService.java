package com.morningstar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

//import com.AirLinesApp.demoAirLines.Service.OtpService;
@Service
public class EmailService {
	 @Autowired
	    private JavaMailSender emailSender;
	    
	    @Autowired
	    private OtpService os;
	public void otpToUser(String email) {
    	String createdOtp = os.createOtp();
        SimpleMailMessage message = new SimpleMailMessage(); 
        message.setFrom("petcult2022@gmail.com");
        message.setTo(email); 
        message.setSubject("OTP for Validation of registered user."); 
        message.setText(createdOtp);
        emailSender.send(message);
    }

}
